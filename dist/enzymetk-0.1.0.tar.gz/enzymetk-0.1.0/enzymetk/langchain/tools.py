"""
LangChain Tool wrappers for every registered EnzymeTK tool.

Each wrapper is a ``langchain_core.tools.StructuredTool`` with a Pydantic
input schema so that LLMs can call them with structured arguments.
"""

from __future__ import annotations
import json
from typing import Any, Dict, List, Optional, Type

from pydantic import BaseModel, Field
from langchain_core.tools import StructuredTool

# Ensure all agent tools are registered on import
import enzymetk.agent.tools  # noqa: F401
from enzymetk.agent.registry import ToolRegistry


# ---------------------------------------------------------------------------
# Pydantic input schemas for LangChain tools
# ---------------------------------------------------------------------------

class _SeqRecord(BaseModel):
    id: str = Field(description="Unique identifier")
    sequence: str = Field(description="Amino acid sequence")


class SearchBlastInput(BaseModel):
    """Input for BLAST sequence search."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences to search")
    labels: Optional[List[str]] = Field(
        default=None,
        description="Label per sequence: 'query' or 'reference'. If None, all are queries and a database must be provided.",
    )
    database: Optional[str] = Field(default=None, description="Path to pre-built Diamond DB")
    mode: str = Field(default="blastp", description="BLAST mode (blastp, blastx, etc.)")
    args: Optional[List[str]] = Field(default=None, description="Extra CLI args for Diamond")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")
    num_threads: int = Field(default=1, description="Parallelism")


class SearchMMseqsInput(BaseModel):
    """Input for MMseqs2 search/cluster."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    method: str = Field(default="search", description="'search' or 'cluster'")
    reference_database: Optional[str] = Field(default=None, description="Reference DB path")
    args: Optional[List[str]] = Field(default=None, description="Extra CLI args (e.g. ['--min-seq-id', '0.5'])")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")


class EmbedProteinESMInput(BaseModel):
    """Input for ESM-2 protein embedding."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    model: str = Field(default="esm2_t36_3B_UR50D", description="ESM model name")
    extraction_method: str = Field(default="mean", description="'mean' or 'active_site'")
    active_sites: Optional[List[str]] = Field(default=None, description="Active site residue indices (pipe-separated)")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")
    rep_num: int = Field(default=-1, description="Representation layer number")


class EmbedProteinESM3Input(BaseModel):
    """Input for ESM3 protein embedding."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    extraction_method: str = Field(default="mean", description="Extraction method")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")
    save_tensors: bool = Field(default=False, description="Save raw tensors")


class AnnotateECCleanInput(BaseModel):
    """Input for CLEAN EC annotation."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences to annotate")
    clean_dir: str = Field(description="Path to CLEAN installation app/ directory")
    num_threads: int = Field(default=1, description="Parallelism")
    env_name: str = Field(default="clean", description="Conda environment name")
    args: Optional[List[str]] = Field(default=None, description="Extra CLEAN args")


class AnnotateECCreepInput(BaseModel):
    """Input for CREEP EC annotation."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    creep_dir: str = Field(description="CREEP installation directory")
    creep_cache_dir: str = Field(description="CREEP cache directory")
    modality: str = Field(description="Input modality")
    reference_modality: str = Field(description="Reference modality")


class AnnotateECProteInferInput(BaseModel):
    """Input for ProteInfer EC annotation."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    proteinfer_dir: str = Field(description="ProteInfer installation directory")
    num_threads: int = Field(default=1, description="Parallelism")
    env_name: str = Field(default="proteinfer", description="Conda environment name")


class PredictActiveSiteInput(BaseModel):
    """Input for active site prediction."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    esm2_model: str = Field(default="esm2_t36_3B_UR50D", description="ESM2 model for Squidly")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")
    num_threads: int = Field(default=1, description="Parallelism")


class EmbedChemBERTInput(BaseModel):
    """Input for ChemBERTa molecular embedding."""
    smiles: List[str] = Field(description="SMILES strings")
    ids: Optional[List[str]] = Field(default=None, description="Molecule IDs")
    num_threads: int = Field(default=1, description="Parallelism")


class EmbedDRFPInput(BaseModel):
    """Input for DRFP reaction embedding."""
    smiles: List[str] = Field(description="Reaction SMILES strings (reactants>>products)")
    ids: Optional[List[str]] = Field(default=None, description="Reaction IDs")
    n_folded_length: int = Field(default=2048, description="Length of the folded fingerprint")
    radius: int = Field(default=3, description="Substructure fingerprint radius")
    rings: bool = Field(default=True, description="Include ring information")
    min_radius: int = Field(default=0, description="Minimum substructure radius")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")


class EmbedRxnFPInput(BaseModel):
    """Input for RxnFP reaction embedding."""
    smiles: List[str] = Field(description="Reaction SMILES strings")
    ids: Optional[List[str]] = Field(default=None, description="Reaction IDs")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")


class EmbedSelFormerInput(BaseModel):
    """Input for SELFormer molecular embedding."""
    smiles: List[str] = Field(description="SMILES strings")
    selformer_dir: str = Field(description="SELFormer installation directory")
    model_file: str = Field(description="Path to model weights")
    ids: Optional[List[str]] = Field(default=None, description="Molecule IDs")


class EmbedUniMolInput(BaseModel):
    """Input for UniMol molecular embedding."""
    smiles: List[str] = Field(description="SMILES strings")
    ids: Optional[List[str]] = Field(default=None, description="Molecule IDs")
    unimol_model: str = Field(default="unimolv2", description="UniMol model version")
    unimol_size: str = Field(default="164m", description="Model size")


class DockBoltzInput(BaseModel):
    """Input for Boltz docking."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    substrates: List[str] = Field(description="Substrate SMILES")
    intermediates: List[str] = Field(description="Intermediate SMILES")
    output_dir: str = Field(description="Output directory")


class DockChaiInput(BaseModel):
    """Input for Chai docking."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences")
    substrates: List[str] = Field(description="Substrate SMILES")
    cofactors: Optional[List[str]] = Field(default=None, description="Cofactor SMILES")
    output_dir: str = Field(default="tmp/", description="Output directory")


class DockVinaInput(BaseModel):
    """Input for Vina docking."""
    ids: List[str] = Field(description="Protein IDs")
    structures: List[Optional[str]] = Field(description="PDB file paths (None to fold)")
    sequences: List[str] = Field(description="Protein sequences")
    substrates: List[str] = Field(description="Substrate SMILES")
    substrate_names: List[str] = Field(description="Substrate names")
    active_site_residues: List[str] = Field(description="Active site residue definitions (pipe-separated)")
    output_dir: str = Field(default="tmp/", description="Output directory")


class DesignLigandMPNNInput(BaseModel):
    """Input for LigandMPNN sequence design."""
    pdb_paths: List[str] = Field(description="Full paths to PDB/CIF structures")
    ligand_mpnn_dir: str = Field(description="LigandMPNN installation directory")
    output_dir: str = Field(description="Output directory")
    args: Optional[List[str]] = Field(default=None, description="Extra LigandMPNN args (e.g. fixed residues)")


class SearchFoldSeekInput(BaseModel):
    """Input for FoldSeek similarity search."""
    query_paths: List[str] = Field(description="Paths to query structures")
    ids: List[str] = Field(description="Query IDs")
    reference_database: str = Field(description="FoldSeek reference database path")
    method: str = Field(default="search", description="'search' or 'cluster'")
    query_type: str = Field(default="structures", description="'structures' or 'sequences'")
    args: Optional[List[str]] = Field(default=None, description="Extra FoldSeek args")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")


class StructureSearchFoldSeekInput(BaseModel):
    """Input for FoldSeek structure database search."""
    query_paths: List[str] = Field(description="Paths to PDB query files")
    reference_database_directory: str = Field(description="Reference structure DB directory")
    args: Optional[List[str]] = Field(default=None, description="Extra FoldSeek args")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")


class SimilarityInput(BaseModel):
    """Input for reaction/substrate similarity."""
    smiles: List[str] = Field(description="SMILES strings to compare")
    query_smiles: str = Field(description="Query SMILES to compare against")
    ids: Optional[List[str]] = Field(default=None, description="Molecule IDs")


class ClustalOmegaInput(BaseModel):
    """Input for Clustal Omega MSA."""
    sequences: List[_SeqRecord] = Field(description="Protein sequences to align")
    tmp_dir: Optional[str] = Field(default=None, description="Working directory")


class FastTreeInput(BaseModel):
    """Input for FastTree phylogenetic tree."""
    sequences: List[_SeqRecord] = Field(description="Aligned sequences")
    fasttree_dir: str = Field(description="FastTree installation directory")
    csv_file: str = Field(description="CSV file with aligned sequences")
    output_dir: str = Field(description="Output directory for tree file")


class MetagenomicsPoreChopInput(BaseModel):
    """Input for Porechop adapter trimming."""
    input_files: List[str] = Field(description="Input read file paths")
    output_files: List[str] = Field(description="Output trimmed file paths")
    porechop_dir: str = Field(description="Porechop installation directory")


class MetagenomicsProkkaInput(BaseModel):
    """Input for Prokka gene annotation."""
    input_files: List[str] = Field(description="Contig file paths")
    name: str = Field(description="Sample name for Prokka")
    porechop_dir: str = Field(description="Prokka installation directory")
    output_dir: str = Field(description="Output directory")


# ---------------------------------------------------------------------------
# Tool builder: wraps each registered EnzymeTool as a LangChain StructuredTool
# ---------------------------------------------------------------------------

_INPUT_SCHEMAS: Dict[str, Type[BaseModel]] = {
    "search_blast": SearchBlastInput,
    "search_mmseqs": SearchMMseqsInput,
    "embed_protein_esm": EmbedProteinESMInput,
    "embed_protein_esm3": EmbedProteinESM3Input,
    "annotate_ec_clean": AnnotateECCleanInput,
    "annotate_ec_creep": AnnotateECCreepInput,
    "annotate_ec_proteinfer": AnnotateECProteInferInput,
    "predict_active_site": PredictActiveSiteInput,
    "embed_molecule_chemberta": EmbedChemBERTInput,
    "embed_reaction_drfp": EmbedDRFPInput,
    "embed_reaction_rxnfp": EmbedRxnFPInput,
    "embed_molecule_selformer": EmbedSelFormerInput,
    "embed_molecule_unimol": EmbedUniMolInput,
    "dock_boltz": DockBoltzInput,
    "dock_chai": DockChaiInput,
    "dock_vina": DockVinaInput,
    "design_ligandmpnn": DesignLigandMPNNInput,
    "search_foldseek": SearchFoldSeekInput,
    "structure_search_foldseek": StructureSearchFoldSeekInput,
    "similarity_reaction": SimilarityInput,
    "similarity_substrate": SimilarityInput,
    "align_clustalomega": ClustalOmegaInput,
    "tree_fasttree": FastTreeInput,
    "metagenomics_porechop": MetagenomicsPoreChopInput,
    "metagenomics_prokka": MetagenomicsProkkaInput,
}


def _make_langchain_tool(tool_name: str) -> StructuredTool:
    """Create a LangChain StructuredTool for *tool_name*."""
    tool_cls = ToolRegistry.get(tool_name)
    if tool_cls is None:
        raise ValueError(f"Unknown tool: {tool_name}")

    schema = _INPUT_SCHEMAS.get(tool_name)

    def _run_tool(**kwargs: Any) -> str:
        tool = tool_cls()
        # Convert Pydantic _SeqRecord objects to dicts if present
        for key in ("sequences",):
            if key in kwargs and kwargs[key] and hasattr(kwargs[key][0], "model_dump"):
                kwargs[key] = [s.model_dump() for s in kwargs[key]]
        result = tool.run(**kwargs)
        return json.dumps(result.model_dump(), default=str)

    return StructuredTool.from_function(
        func=_run_tool,
        name=tool_name,
        description=tool_cls.description,
        args_schema=schema,
    )


def build_all_tools() -> List[StructuredTool]:
    """Build LangChain tools for every registered EnzymeTK tool."""
    tools: List[StructuredTool] = []
    for name in ToolRegistry.list_names():
        try:
            tools.append(_make_langchain_tool(name))
        except Exception:
            # Skip tools whose dependencies are not installed
            pass
    return tools
