"""
EnzymeTKToolkit - a LangChain BaseToolkit that bundles all enzyme tools.
"""

from __future__ import annotations
from typing import List, Optional

from langchain_core.tools import BaseTool

from enzymetk.langchain.tools import build_all_tools, _make_langchain_tool

# Ensure all agent tools are registered
import enzymetk.agent.tools  # noqa: F401
from enzymetk.agent.registry import ToolRegistry


class EnzymeTKToolkit:
    """Collection of all EnzymeTK tools exposed as LangChain tools.

    Usage::

        toolkit = EnzymeTKToolkit()
        tools = toolkit.get_tools()
        # pass *tools* to any LangChain agent
    """

    def get_tools(self, categories: Optional[List[str]] = None) -> List[BaseTool]:
        """Return LangChain tools, optionally filtered by category.

        Parameters
        ----------
        categories : list of str, optional
            If provided, only return tools whose category matches one of
            these values (e.g. ``["search", "annotation"]``).
        """
        if categories is None:
            return build_all_tools()

        selected: List[BaseTool] = []
        for info in ToolRegistry.list_tools():
            if info.category in categories:
                try:
                    selected.append(_make_langchain_tool(info.name))
                except Exception:
                    pass
        return selected

    def list_tools(self) -> List[dict]:
        """Return metadata dicts for all available tools."""
        return [
            {
                "name": info.name,
                "description": info.description,
                "category": info.category,
                "required_env": info.required_env,
            }
            for info in ToolRegistry.list_tools()
        ]
