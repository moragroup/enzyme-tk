"""
Pre-configured agent factory for enzyme engineering tasks.

Provides ``create_enzyme_agent()`` which sets up a LangChain agent with all
EnzymeTK tools and a system prompt that understands enzyme engineering context.
"""

from __future__ import annotations
from typing import Any, List, Optional

from langchain_core.language_models import BaseLanguageModel
from langchain_core.tools import BaseTool

from enzymetk.langchain.toolkit import EnzymeTKToolkit


SYSTEM_PROMPT = """\
You are an expert enzyme engineering assistant with access to a comprehensive
toolkit of bioinformatics and cheminformatics tools. You help researchers with:

- **Enzyme Discovery**: Finding novel enzymes via sequence/structure search
- **Enzyme Annotation**: Predicting EC numbers and catalytic functions  
- **Enzyme Characterization**: Generating embeddings, predicting active sites
- **Enzyme Engineering**: Designing mutations via LigandMPNN, docking validation
- **Metagenomics**: Processing raw sequencing reads and annotating genes

When the user describes a task, determine which tools to call and in what order.
Always explain your reasoning before calling a tool. After each tool call,
summarise the results and suggest next steps.

Input data conventions:
- Protein sequences are provided as lists of {{id, sequence}} objects
- Chemical structures are SMILES strings
- Protein structures are paths to PDB/CIF files
- Tool results are saved as pickle files; reference the output_path for chaining

Available tool categories: annotation, docking, embedding, search, alignment,
design, prediction, metagenomics.
"""


def create_enzyme_agent(
    llm: BaseLanguageModel,
    tools: Optional[List[BaseTool]] = None,
    categories: Optional[List[str]] = None,
    system_prompt: str = SYSTEM_PROMPT,
    verbose: bool = True,
    **agent_kwargs: Any,
) -> Any:
    """Create a LangChain agent pre-loaded with EnzymeTK tools.

    Parameters
    ----------
    llm : BaseLanguageModel
        The LLM to power the agent (e.g. ``ChatOpenAI(model="gpt-4")``).
    tools : list of BaseTool, optional
        Override the tool list. If None, all EnzymeTK tools are loaded.
    categories : list of str, optional
        Filter tools by category (e.g. ``["search", "annotation"]``).
    system_prompt : str
        System message that gives the agent enzyme-engineering context.
    verbose : bool
        Whether to print agent reasoning steps.
    **agent_kwargs
        Additional kwargs forwarded to ``create_tool_calling_agent``.

    Returns
    -------
    AgentExecutor
        A ready-to-use LangChain agent executor.

    Example
    -------
    >>> from langchain_openai import ChatOpenAI
    >>> from enzymetk.langchain import create_enzyme_agent, EnzymeTKToolkit
    >>>
    >>> llm = ChatOpenAI(model="gpt-4")
    >>> agent = create_enzyme_agent(llm)
    >>> result = agent.invoke({"input": "Search for esterases similar to AXE2"})
    """
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
    from langchain.agents import AgentExecutor, create_tool_calling_agent

    if tools is None:
        toolkit = EnzymeTKToolkit()
        tools = toolkit.get_tools(categories=categories)

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        MessagesPlaceholder("chat_history", optional=True),
        ("human", "{input}"),
        MessagesPlaceholder("agent_scratchpad"),
    ])

    agent = create_tool_calling_agent(llm, tools, prompt, **agent_kwargs)
    return AgentExecutor(agent=agent, tools=tools, verbose=verbose)
