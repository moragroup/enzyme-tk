from drfp import DrfpEncoder
import pandas as pd
import pickle
import argparse
import numpy as np


def run_drfp(output_filename, input_filename, label, n_folded_length, radius, rings, min_radius):
    df = pd.read_csv(input_filename)
    rxns = df[label].values.tolist()
    fps = DrfpEncoder.encode(
        rxns,
        n_folded_length=n_folded_length,
        radius=radius,
        rings=rings,
        min_radius=min_radius,
    )
    df['drfp'] = [np.array(fp) for fp in fps]
    with open(output_filename, 'wb') as file:
        pickle.dump(df, file)


def parse_args():
    parser = argparse.ArgumentParser(description="Run DRFP on a dataset")
    parser.add_argument('-out', '--out', required=True, help='Path to the output file')
    parser.add_argument('-input', '--input', type=str, required=True, help='Path to the input dataframe CSV')
    parser.add_argument('-label', '--label', type=str, required=True, help='Column name for reaction SMILES')
    parser.add_argument('-n_folded_length', '--n_folded_length', type=int, default=2048,
                        help='Length of the folded fingerprint')
    parser.add_argument('-radius', '--radius', type=int, default=3,
                        help='Radius of the substructure fingerprint')
    parser.add_argument('-rings', '--rings', action='store_true', default=True,
                        help='Include ring information')
    parser.add_argument('-min_radius', '--min_radius', type=int, default=0,
                        help='Minimum radius of the substructure fingerprint')
    return parser.parse_args()


def main():
    args = parse_args()
    run_drfp(args.out, args.input, args.label,
             args.n_folded_length, args.radius, args.rings, args.min_radius)


main()
